function random(value){
	return Math.round(Math.random() * value);
}

function mainTwo(color){
	let listeLetter = "0123456789ABCDEF";
	let hexaDecimal = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"];
	let newChain = color[1]+color[2]+color[3]+color[4]+color[5]+color[6];
	let rgbaNotConvert = "";
	for(let k = 0; k < newChain.length; k++){
		rgbaNotConvert += hexaDecimal[listeLetter.indexOf(newChain[k])];
	}
	let r = 0, g = 0, b = 0;
	let comparaison = 0;
	for(let c = 7; c > 0; c--){
		if(rgbaNotConvert[comparaison] == "1"){
			r += 2**c;
		}
		comparaison += 1;
	}
	comparaison = 8;
	for(let c = 7; c > 0; c--){
		if(rgbaNotConvert[comparaison] == "1"){
			g += 2**c;
		}
		comparaison += 1;
	}
	comparaison = 16;
	for(let c = 7; c > 0; c--){
		if(rgbaNotConvert[comparaison] == "1"){
			b += 2**c;
		}
		comparaison += 1;
	}
	document.querySelector("#r").value = r;
	document.querySelector("#g").value = g;
	document.querySelector("#b").value = b;
	document.querySelector("#rvalue").value = r;
	document.querySelector("#gvalue").value = g;
	document.querySelector("#bvalue").value = b;
	let canvas = document.getElementById("canvas");
	let ctx = canvas.getContext("2d");
	ctx.fillStyle = color;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
}
function colorRandom(){
	let color = "#";
	let listeLetter = "0123456789ABCDEF";
	let hexaDecimal = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"];
	for(let i = 0; i < 6; i++){
		color += listeLetter[random(15)];
	}
	mainTwo(color);
	document.querySelector("#hexa").value = color;
}
function main(r, g, b){
	let binary = "";
	let hexadecimal = "#";
	let hexaDecimal = ["0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111"];
	let listeLetter = "0123456789ABCDEF";
	for(let k = 8; k > 0; k--){
		if(r >= (2**(k-1)) && r <= (2**k)){
			binary += "1";
			r -= (2**(k-1));
		}
		else{
			binary += "0";
		}
	}
	for(let k = 8; k > 0; k--){
		if(g >= (2**(k-1)) && g <= (2**k)){
			binary += "1";
			g -= (2**(k-1));
		}
		else{
			binary += "0";
		}
	}
	for(let k = 8; k > 0; k--){
		if(b >= (2**(k-1)) && b <= (2**k)){
			binary += "1";
			b -= (2**(k-1));
		}
		else{
			binary += "0";
		}
	}
	for(let c = 0; c < binary.length; c+= 4){
		hexadecimal += listeLetter[hexaDecimal.indexOf((binary[c]+binary[c+1]+binary[c+2]+binary[c+3]))];
	}
	document.querySelector("#hexa").value = hexadecimal;
}
function changeColor(){
	let r = document.querySelector("#r").value;
	let g = document.querySelector("#g").value;
	let b = document.querySelector("#b").value;
	document.querySelector("#rvalue").value = r;
	document.querySelector("#gvalue").value = g;
	document.querySelector("#bvalue").value = b;
	let canvas = document.getElementById("canvas");
	let ctx = canvas.getContext("2d");
	ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	main(r, g, b);
}

function changeColorInput(){
	let r = document.querySelector("#rvalue").value;
	let g = document.querySelector("#gvalue").value;
	let b = document.querySelector("#bvalue").value;
	if(r == ''){
		r = 0;
		document.querySelector("#rvalue").value = `${r}`;
	}
	if(g == ''){
		g = 0;
		document.querySelector("#gvalue").value = `${g}`;
	}
	if(b == ''){
		b = 0;
		document.querySelector("#bvalue").value = `${b}`;
	}
	console.log(`R : ${r}   G : ${g}   B : ${b}`);
	document.querySelector("#r").value = r;
	document.querySelector("#g").value = g;
	document.querySelector("#b").value = b;
	let canvas = document.getElementById("canvas");
	let ctx = canvas.getContext("2d");
	ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	main(r, g, b);
}
function changeColorInputHexadecimal(){
	if(document.querySelector("#hexa").value.length == 7){
		let color = document.querySelector("#hexa").value;
		mainTwo(color);
	}
	else{
		let color = '#000000';
		document.querySelector("#hexa").value = color;
		mainTwo(color);
	}
}
colorRandom();